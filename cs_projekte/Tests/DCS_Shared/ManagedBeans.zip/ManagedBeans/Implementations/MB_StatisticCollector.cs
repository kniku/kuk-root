﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RCS.Common.Tools;
using RCS.Common.Logger;
using RCS;

namespace DCS.ManagedBeans.Implementations
{
	class MB_StatisticCollector : AbstractManagedThreadedBean
	{
		SleepingThreadTimer MinutenTimer = new SleepingThreadTimer();
		DBTools DBTools;
		T_machines[] Machines;
		T_curvetypes[] CT;
		SC_Tools[] SC;
		T_statistic[] StatisticLeft;
		T_statistic[] StatisticRight;
		T_statestat[] StateStat;
		
		// Cleanup Stuff
		Int32 BackupDays;
		DateTime lastCleanup;

		protected override int getTimeoutMS()
		{
			return 100;
		}

		public override string getName()
		{
			return "Statistic Collector";
		}

		public override string getDescription()
		{
			return "Sammelt Statistikdaten von allen konfigurierten Maschinen";
		}
		
		public override void start()
		{
			base.start();
			DBTools = new RCS.DBTools();
			DBTools.ConnectToServer(AppGlobal.DB_Host, AppGlobal.DB_User, AppGlobal.DB_Pass, AppGlobal.DB_Database, 120);

			// Konfigurierte Maschinen laden...
			Machines = (RCS.T_machines[])DBTools.select_rows(RCS.E_Tables.E_T_machines, "Ma_Status <> " + (short)RCS.Status.DELETED, 0);
			if (Machines == null || Machines.Length <= 0)
			{
				logger.LogWarning("Stopped, no machines defined!");
				stop();
				return;
			}

			// curvetypes laden...
			CT = (T_curvetypes[])DBTools.select_rows(E_Tables.E_T_curvetypes, "", "Ct_ID", 0);

			// Konfigurierte Maschinen loggen
			if (logger.isLevelEnabled(LogLevel.Info))
			{
				logger.LogInfo("{0}: Configured Machines:", getName());
				foreach (RCS.T_machines aMachine in Machines)
				{
					logger.LogInfo("{0}: Machine \"{2}\": ID={1}, IP={3}", getName(), aMachine.Ma_ID, aMachine.Ma_Name, aMachine.Ma_IPAdr);
				}
			}

			// Verbindungen zu den Maschinen herstellen...
			SC = new RCS.SC_Tools[Machines.Length];
			for (Int32 i = 0; i < Machines.Length; i++)
			{
				SC[i] = new RCS.SC_Tools();
				if (!SC[i].ConnectToServer(Machines[i].Ma_IPAdr, 11240))
				{
					logger.LogError("{0}: Machine {1} NOT connected!", getName(), Machines[i].Ma_Name);
				}
			}

			// Puffer initialisieren...
			StatisticLeft = new RCS.T_statistic[Machines.Length];
			StatisticRight = new RCS.T_statistic[Machines.Length];
			StateStat = new RCS.T_statestat[Machines.Length];

			BackupDays = AppGlobal.Config.getParameter(DCSParameter.STORAGE_DAYS, DCSParameter.STORAGE_DAYS_DEFAULT);
			logger.LogInfo("{0}: Configured Storage: {1} days", getName(), BackupDays);
			lastCleanup = DateTime.MinValue;	// Nach Startup gleich mal Cleanup starten...

		}

		public override void stop()
		{
			base.stop();
			MinutenTimer.stop();
			if (DBTools != null)
			{
				DBTools.CloseConnectionToServer();
				DBTools = null;
			}
			Machines = null;
			StatisticLeft = null;
			StatisticRight = null;
			StateStat = null;
			SC = null;
			CT = null;
		}

		public override void beanRun()
		{
			if (!MinutenTimer.isExpired) return;
			MinutenTimer.start(1000 * 60);	// Timer auf eine Minute stellen...

			logger.LogInfo("{0}: beanRun...", getName());

			logger.LogInfo("{0}: Time Cycle-Start", getName());
			FeedAllStateStatAndStatisticToDB();
			logger.LogInfo("{0}: Time Stat/Statistic done", getName());
			GetOverviewMonitoring();
			logger.LogInfo("{0}: Time Overview-Monitoring done", getName());
			CleanupStatisticData();
			RCS.CommonTools.ImAliveUpdate(DBTools, "CollectorAlive");

			logger.LogInfo("{0}: Time Cycle-End", getName());
			logger.LogInfo("{0}: #########################################################", getName());
		}

		/// <summary>
		/// Fragt alle Statistik und StateStat Werte bei der Maschine ab und speichert diese Zyklisch in die Datenbank
		/// </summary>
		private void FeedAllStateStatAndStatisticToDB()
		{
			RCS.T_statestat SS_Temp = null;
			RCS.T_statistic ST_L_Temp = null;
			RCS.T_statistic ST_R_Temp = null;
			Int32 rv = 0, count_StateStat = 0, count_Statistic_L = 0, count_Statistic_R = 0;
			count_StateStat = 0;
			count_Statistic_L = 0;
			count_Statistic_R = 0;

			try
			{
				for (Int32 i = 0; i < Machines.Length; i++)
				{
					if (SC[i].ConnState == true)
					{
						rv = 0;
						SS_Temp = null;
						ST_L_Temp = null;
						ST_R_Temp = null;

						rv = SC[i].getStateStatAndStatisticFromMachine(ref SS_Temp, ref ST_L_Temp, ref ST_R_Temp, ((Machines[i].Sl_ID == 2) ? true : false));

						if (rv == 0)
						{
							StateStat[i] = SS_Temp;

							if (StateStat[i] != null)
								count_StateStat++;
							StateStat[i].Ma_ID = Machines[i].Ma_ID;
							StateStat[i].Ss_TimeStamp = RCS.CommonTools.getNowWithoutSec();

							if (SS_Temp.Ss_Status == (int)RCS.CommonTools.MachineState.Run || SS_Temp.Ss_Status == (int)RCS.CommonTools.MachineState.Warning)
							{
								StatisticLeft[i] = ST_L_Temp;
								StatisticRight[i] = ST_R_Temp;

								if (StatisticLeft[i] != null)
								{
									count_Statistic_L++;

									StatisticLeft[i].Ma_ID = Machines[i].Ma_ID;
									StatisticLeft[i].Si_ID = 1;
									StatisticLeft[i].St_TimeStamp = RCS.CommonTools.getNowWithoutSec();
								}

								if (Machines[i].Sl_ID == 2 && StatisticRight[i] != null)
								{
									count_Statistic_R++;
									StatisticRight[i].Ma_ID = Machines[i].Ma_ID;
									StatisticRight[i].Si_ID = 2;
									StatisticRight[i].St_TimeStamp = RCS.CommonTools.getNowWithoutSec();
								}
								logger.LogInfo("{0}: MACHINE: {1} / MSG: StateStat-data and Statistic-data successfully collected", getName(), Machines[i].Ma_Name);
							}
							else
							{
								logger.LogWarning("{0}: MACHINE: {1} / MSG: Machine off, Data not collected!", getName(), Machines[i].Ma_Name);
							}
						}
						else
						{
							logger.LogWarning("{0}: MACHINE: {1} / MSG: ...no data received.........!!!!", getName(), Machines[i].Ma_Name);
						}
					}
				}

				if (count_StateStat != 0 && count_Statistic_L != 0)
				{
					Int32 inserted_StateStat = DBTools.insert_rows(RCS.E_Tables.E_T_statestat, StateStat);
					if (count_StateStat > inserted_StateStat)
					{
						logger.LogWarning("{0}: Saved statestat-data and number of running machines not equal!!! Rows to insert: {1}, Inserted Rows: {2}", getName(), count_StateStat, inserted_StateStat);
					}

					Int32 inserted_Statistic_L = DBTools.insert_rows(RCS.E_Tables.E_T_statistic, StatisticLeft);
					if (count_Statistic_L > inserted_Statistic_L)
					{
						logger.LogWarning("{0}: Saved statistic-data and number of running machines not equal (Slide Side Left)!!! Rows to insert: {1}, Inserted Rows: {2}", getName(), count_Statistic_L, inserted_Statistic_L);
					}

					if (count_Statistic_R > 0)
					{
						Int32 inserted_Statistic_R = DBTools.insert_rows(RCS.E_Tables.E_T_statistic, StatisticRight);
						if (count_Statistic_R > inserted_Statistic_R)
						{
							logger.LogWarning("{0}: Saved statistic-data and number of running machines not equal (Slide Side Right)!!! Rows to insert: {1}, Inserted Rows: {2}", getName(), count_Statistic_R, inserted_Statistic_R);
						}
					}
				}
				else
				{
					logger.LogWarning("{0}: There are no machinestatistics added to the database!!!", getName());
				}
			}
			catch (Exception e)
			{
				logger.LogError("{0}: Collector.GetStatistic: {1}", getName(), e);
			}
		}
		/// <summary>
		/// Cleant zyklisch alle Tabellen der DB; Löscht alle Status "3" Datensätze
		/// </summary>
		private void CleanupStatisticData()
		{
			//"Alte" Statistikwerte loeschen
			int count_rows = 0;
			DateTime DeleteDate = DateTime.Now;

			if (BackupDays > 0 && (DeleteDate - lastCleanup).TotalHours > 24)
			{
				lastCleanup = DeleteDate;	// Merken; Cleanup nur 1 x pro Tag

				DeleteDate = DeleteDate.AddDays(BackupDays * -1);
				logger.LogInfo("{0}: Cleanup statistic data older than {1} days", getName(), BackupDays);

				String DeleteDateDBStr = "'" + DBTools.getSqlDateTimeStr(DeleteDate) + "'";

				//Bereinigen Tabelle: statestat
				count_rows = DBTools.execute_sql("DELETE FROM statestat WHERE Ss_TimeStamp < " + DeleteDateDBStr);
				logger.LogInfo("{0}: Cleanup Table StateStat: {1} rows deleted", getName(), count_rows > 0 ? count_rows : 0);
				//Bereinigen Tabelle: statistic
				count_rows = DBTools.execute_sql("DELETE FROM statistic WHERE St_TimeStamp < " + DeleteDateDBStr);
				logger.LogInfo("{0}: Cleanup Table Statistic: {1} rows deleted", getName(), count_rows > 0 ? count_rows : 0);
				//Bereinigen Tabelle: feedingmonitoringdata
				count_rows = DBTools.execute_sql("DELETE FROM feedingmonitoringdata WHERE Fd_TimeStamp < " + DeleteDateDBStr);
				logger.LogInfo("{0}: Cleanup Table FeedingMonitoringData: {1} rows deleted", getName(), count_rows > 0 ? count_rows : 0);
				//Bereinigen Tabelle: screenmatsmonitoringdata
				count_rows = DBTools.execute_sql("DELETE FROM screenmatsmonitoringdata WHERE Sd_TimeStamp < " + DeleteDateDBStr);
				logger.LogInfo("{0}: Cleanup Table ScreenmatsMonitoringData: {1} rows deleted", getName(), count_rows > 0 ? count_rows : 0);
				//Bereinigen Tabelle: machinemonitoringdata
				count_rows = DBTools.execute_sql("DELETE FROM machinemonitoringdata WHERE Md_TimeStamp < " + DeleteDateDBStr);
				logger.LogInfo("{0}: Cleanup Table MachineMonitoringData: {1} rows deleted", getName(), count_rows > 0 ? count_rows : 0);
				//Bereinigen Tabelle: overviewmonitoringdata
				count_rows = DBTools.execute_sql("DELETE FROM overviewmonitoringdata WHERE Od_TimeStamp < " + DeleteDateDBStr);
				logger.LogInfo("{0}: Cleanup Table OverviewMonitoringData: {1} rows deleted", getName(), count_rows > 0 ? count_rows : 0);
				//Bereinigen Tabelle: userlog
				count_rows = DBTools.execute_sql("DELETE FROM userlog WHERE Ul_DateTime < " + DeleteDateDBStr);
				logger.LogInfo("{0}: Cleanup Table UserLog: {1} rows deleted", getName(), count_rows > 0 ? count_rows : 0);
				//Bereinigen Tabelle: plantstatistic
				count_rows = DBTools.execute_sql("DELETE FROM plantstatistic WHERE Ps_TimeStamp < " + DeleteDateDBStr);
				logger.LogInfo("{0}: Cleanup Table PlantStatistic: {1} rows deleted", getName(), count_rows > 0 ? count_rows : 0);
			}
		}

		/// <summary>
		/// Berechnet aus den zuvor in die DB geschriebenen Statistik und StateStat die Monitor Daten und speichert diese ebenfalls in der DB
		/// </summary>
		private void GetOverviewMonitoring()
		{
			Int16[] status = new Int16[1], profil = new Int16[1], config = new Int16[1], SortProg = new Int16[1];
			Int32[] Objects_Pass = new Int32[1], Objects_Rej1 = new Int32[1], Objects_Rej2 = new Int32[1];
			Int32[] Weight_Pass = new Int32[1], Weight_Rej1 = new Int32[1], Weight_Rej2 = new Int32[1];
			DateTime[] Timestamp = new DateTime[1];
			Single Highest_Value = 0;

			// Daten aus DB holen und bei Feedingmonitoring in Feedingmonitoringdata speichern
			// Durchlauf pro Maschine
			for (Int32 i = 0; i < Machines.Length; i++)
			{
				// Durchlauf für gegebenenfalls mehrere Spuren
				for (Int32 j = 0; j < Machines[i].Sl_ID; j++)
				{
					String Str = "SELECT ss.ss_status FROM StateStat AS ss WHERE ss.Ma_ID = " + Machines[i].Ma_ID + " ORDER BY ss.Ss_TimeStamp DESC LIMIT 1; ";
					DBTools.select_c_row(Str, status);

					if (!(status[0] == (int)RCS.CommonTools.MachineState.Run || status[0] == (int)RCS.CommonTools.MachineState.Warning))
						continue;

					// DB-Abfrage auf letzten Datensatz von einzelnen SlideSides
					Objects_Pass[0] = 0; Objects_Rej1[0] = 0; Objects_Rej2[0] = 0;
					Weight_Pass[0] = 0; Weight_Rej1[0] = 0; Weight_Rej2[0] = 0;
					SortProg[0] = 0;
					Timestamp = null; Timestamp = new DateTime[1];
					Str = "";

					try
					{
						// Abfrage für die linke Seite // GsM: Habe GROUP BY durch ORDER BY ersetzt:
						Str = "SELECT ";
						if (j == 0)
						{
							Str += "(SELECT ss.ss_profil_left FROM StateStat AS ss WHERE ss.Ma_ID = " + Machines[i].Ma_ID + " ORDER BY ss.Ss_TimeStamp DESC LIMIT 1) AS Profil_Left, ";
							Str += "(SELECT ss.ss_config_left FROM StateStat AS ss WHERE ss.Ma_ID = " + Machines[i].Ma_ID + " ORDER BY ss.Ss_TimeStamp DESC LIMIT 1) AS Config_Left, ";
						}
						// Abfrage für die rechte Seite
						else if (j == 1)
						{
							Str += "(SELECT ss.ss_profil_right FROM StateStat AS ss WHERE ss.Ma_ID = " + Machines[i].Ma_ID + " ORDER BY ss.Ss_TimeStamp DESC LIMIT 1) AS Profil_Right, ";
							Str += "(SELECT ss.ss_config_right FROM StateStat AS ss WHERE ss.Ma_ID = " + Machines[i].Ma_ID + " ORDER BY ss.Ss_TimeStamp DESC LIMIT 1) AS Config_Right, ";
						}

						Str += "(SELECT ss.ss_sorting_num_0 FROM StateStat AS ss WHERE ss.Ma_ID = " + Machines[i].Ma_ID + " ORDER BY ss.Ss_TimeStamp DESC LIMIT 1) AS Status, " +
								"(SELECT st.st_objects_pass FROM Statistic AS st WHERE st.Ma_ID = " + Machines[i].Ma_ID + " AND st.Si_ID = " + (j + 1) + " ORDER BY st.St_TimeStamp DESC LIMIT 1) AS objects_pass, " +
								"(SELECT st.st_objects_rej_1 FROM Statistic AS st WHERE st.Ma_ID = " + Machines[i].Ma_ID + " AND st.Si_ID = " + (j + 1) + " ORDER BY st.St_TimeStamp DESC LIMIT 1) AS objects_rej1, " +
								"(SELECT st.st_objects_rej_2 FROM Statistic AS st WHERE st.Ma_ID = " + Machines[i].Ma_ID + " AND st.Si_ID = " + (j + 1) + " ORDER BY st.St_TimeStamp DESC LIMIT 1) AS objects_rej2, " +
								"(SELECT st.st_sort_weight_pass FROM Statistic AS st WHERE st.Ma_ID = " + Machines[i].Ma_ID + " AND st.Si_ID = " + (j + 1) + " ORDER BY st.St_TimeStamp DESC LIMIT 1) AS weight_pass, " +
								"(SELECT st.st_sort_weight_rej_1 FROM Statistic AS st WHERE st.Ma_ID = " + Machines[i].Ma_ID + " AND st.Si_ID = " + (j + 1) + " ORDER BY st.St_TimeStamp DESC LIMIT 1) AS weight_rej1, " +
								"(SELECT st.st_sort_weight_rej_2 FROM Statistic AS st WHERE st.Ma_ID = " + Machines[i].Ma_ID + " AND st.Si_ID = " + (j + 1) + " ORDER BY st.St_TimeStamp DESC LIMIT 1) AS weight_rej2, " +
								"(SELECT st.st_timestamp FROM Statistic AS st WHERE st.Ma_ID = " + Machines[i].Ma_ID + " AND st.Si_ID = " + (j + 1) + " ORDER BY st.St_TimeStamp DESC LIMIT 1) AS timestamp; ";

						DBTools.select_c_row(Str, profil, config, SortProg, Objects_Pass, Objects_Rej1, Objects_Rej2, Weight_Pass, Weight_Rej1, Weight_Rej2, Timestamp);
					}
					catch
					{
						logger.LogError("{0}: There was an Error while retrieving Data from the Database", getName());
					}
					if (RCS.CommonTools.CompareWithNowWithoutSec(Timestamp[0]) == false)
					{
						//MSG
						continue;
					}

					// TODO: Abfrage ob Zeitpunkt des Statistik und StateStat Datensatzes gleich ist bei Links oder Rechts

					RCS.T_programs Pr = null;
					RCS.T_machinelimits Ml = null;
					RCS.T_feedingmonitoringprograms FMP = null;
					Int32 Objects_pr = 0, Weight_pr = 0, Objects_Rej1_pr = 0, Objects_Rej2_pr = 0, Weight_Rej1_pr = 0, Weight_Rej2_pr = 0;
					RCS.T_limits Lim = null;

					// Programm laden und Load berechnen
					// Linke Seite
					if (SortProg[0] >= 0)
					{
						// Program abfragen
						Pr = (RCS.T_programs)DBTools.select_row(RCS.E_Tables.E_T_programs, "Pr_Number = " + SortProg[0] + " AND Ma_ID = " + Machines[i].Ma_ID + " AND Si_ID = " + Convert.ToString(j + 1) + " AND Pr_Status <> " + (short)RCS.Status.DELETED);

						if (Pr == null)
						{
							// Nicht alle Programme von Maschine in DB (Programm Update machen) z.b. bei Spur 2 aktivierung!!!
							logger.LogError("{0}: There are not all needed Programs and Classes in the Database!! Update SortingProgram {1} of the Machine {2} on SlideSide {3} in the Configuration!!", getName(), SortProg[0], Machines[i].Ma_Name, Convert.ToString(j + 1));
							continue;
						}
						// Limit der ausgelesenen Maschine holen
						Ml = (RCS.T_machinelimits)DBTools.select_row(RCS.E_Tables.E_T_machinelimits, "Pr_ID = " + Pr.Pr_ID + " AND Si_ID = " + Pr.Si_ID + " AND Ml_Status <> " + (short)RCS.Status.DELETED);
						FMP = (RCS.T_feedingmonitoringprograms)DBTools.select_row(RCS.E_Tables.E_T_feedingmonitoringprograms, "Pr_ID = " + Pr.Pr_ID + " AND Fp_Status <> " + (short)RCS.Status.DELETED);

						// Wenn es keine Limits gibt, wird keine Verarbeitung der Statistik-Daten durchgeführt
						if (Ml != null)
						{
							Lim = (RCS.T_limits)DBTools.select_row(RCS.E_Tables.E_T_limits, "Li_ID = " + Ml.Li_ID + " AND Li_Status <> " + (short)RCS.Status.DELETED);

							// Load Berechnen
							//--------------------------
							if (Lim.Li_NrOfObjMax != 0)
								Objects_pr = Convert.ToInt32(100.00f / Lim.Li_NrOfObjMax * (Objects_Pass[0] + Objects_Rej1[0] + Objects_Rej2[0]));
							if (Lim.Li_WeightMax != 0)
								Weight_pr = Convert.ToInt32(100.00f / Lim.Li_WeightMax * (Weight_Pass[0] + Weight_Rej1[0] + Weight_Rej2[0]));

							if (Lim.Li_NrOfObjRejMax_B1 != 0)
								Objects_Rej1_pr = Convert.ToInt32(100.00f / Lim.Li_NrOfObjRejMax_B1 * Objects_Rej1[0]);
							if (Lim.Li_NrOfObjRejMax_B2 != 0)
								Objects_Rej2_pr = Convert.ToInt32(100.00f / Lim.Li_NrOfObjRejMax_B2 * Objects_Rej2[0]);

							if (Lim.Li_WeightRejMax_B1 != 0)
								Weight_Rej1_pr = Convert.ToInt32(100.00f / Lim.Li_WeightRejMax_B1 * Weight_Rej1[0]);
							if (Lim.Li_WeightRejMax_B2 != 0)
								Weight_Rej2_pr = Convert.ToInt32(100.00f / Lim.Li_WeightRejMax_B2 * Weight_Rej2[0]);


							// Der jeweils höhere Wert (Objects oder Weight) wird in Highest_Value geschrieben, dies gilt für die jeweilige Slideside
							Highest_Value = 0;
							if (Weight_pr > Objects_pr)
								Highest_Value = Weight_pr;
							else
								Highest_Value = Objects_pr;
							if (Objects_Rej1_pr > Highest_Value)
								Highest_Value = Objects_Rej1_pr;
							if (Objects_Rej2_pr > Highest_Value)
								Highest_Value = Objects_Rej2_pr;
							if (Weight_Rej1_pr > Highest_Value)
								Highest_Value = Weight_Rej1_pr;
							if (Weight_Rej2_pr > Highest_Value)
								Highest_Value = Weight_Rej2_pr;


							// Befüllen von OverviewMonitoringData
							RCS.T_overviewmonitoringdata OMD = new RCS.T_overviewmonitoringdata();
							OMD.Ma_ID = Machines[i].Ma_ID;
							if (j == 0)
								OMD.Si_ID = 1;
							else
								OMD.Si_ID = 2;
							OMD.Wi_ID = Machines[i].Wi_ID;
							OMD.Rj_ID = Machines[i].Rj_ID;
							OMD.Sl_ID = Machines[i].Sl_ID;
							if (Ml != null && Highest_Value <= 600)
								OMD.Od_Load = Convert.ToInt32(Highest_Value * 100);
							else
								OMD.Od_Load = -1;
							OMD.Od_SortProg = SortProg[0];
							OMD.Od_Profil = profil[0];
							if (config[0] >= 0)
								OMD.Od_Config = config[0];
							else
								OMD.Od_Config = 0;

							OMD.Od_Objects = Objects_Pass[0] + Objects_Rej1[0] + Objects_Rej2[0];
							OMD.Od_Objects_Rej1 = Objects_Rej1[0];
							OMD.Od_Objects_Rej2 = Objects_Rej2[0];

							if (Objects_pr <= 60000)
								OMD.Od_Objects_pr = Objects_pr * 100;
							else
								OMD.Od_Objects_pr = -1;
							if (Objects_Rej1_pr <= 60000)
								OMD.Od_Objects_pr_Rej1 = Objects_Rej1_pr * 100;
							else
								OMD.Od_Objects_pr_Rej1 = -1;
							if (Objects_Rej2_pr <= 60000)
								OMD.Od_Objects_pr_Rej2 = Objects_Rej2_pr * 100;
							else
								OMD.Od_Objects_pr_Rej2 = -1;

							OMD.Od_Weight = Weight_Pass[0] + Weight_Rej1[0] + Weight_Rej2[0];
							OMD.Od_Weight_Rej1 = Weight_Rej1[0];
							OMD.Od_Weight_Rej2 = Weight_Rej2[0];

							if (Weight_pr <= 600)
								OMD.Od_Weight_pr = Weight_pr * 100;
							else
								OMD.Od_Weight_pr = -1;
							if (Weight_Rej1_pr <= 600)
								OMD.Od_Weight_pr_Rej1 = Weight_Rej1_pr * 100;
							else
								OMD.Od_Weight_pr_Rej1 = -1;
							if (Weight_Rej2_pr <= 600)
								OMD.Od_Weight_pr_Rej2 = Weight_Rej2_pr * 100;
							else
								OMD.Od_Weight_pr_Rej2 = Weight_Rej2_pr * 100;

							DateTime DT = RCS.CommonTools.getNowWithoutSec();
							OMD.Od_TimeStamp = DT;

							RCS.T_overviewmonitoringdata OMD_Last = (RCS.T_overviewmonitoringdata)DBTools.select_row(RCS.E_Tables.E_T_overviewmonitoringdata, "Ma_ID = " + OMD.Ma_ID + " AND Si_ID = " + OMD.Si_ID + " AND Wi_ID = " + OMD.Wi_ID + " AND Rj_ID = " + OMD.Rj_ID + " AND Sl_ID = " + OMD.Sl_ID + " ORDER BY Od_TimeStamp DESC LIMIT 1");
							if (OMD_Last == null)
								OMD_Last = OMD;

							DBTools.insert_row(RCS.E_Tables.E_T_overviewmonitoringdata, OMD);

							OMD = null;
							OMD = (RCS.T_overviewmonitoringdata)DBTools.select_row(RCS.E_Tables.E_T_overviewmonitoringdata, "Ma_ID = " + OMD_Last.Ma_ID + " AND Si_ID = " + OMD_Last.Si_ID + " AND Wi_ID = " + OMD_Last.Wi_ID + " AND Rj_ID = " + OMD_Last.Rj_ID + " AND Sl_ID = " + OMD_Last.Sl_ID + " ORDER BY Od_TimeStamp DESC LIMIT 1");

							// FEEDING UND SCREENMATS MONITORING ABFRAGE FÜR DIESE MASCHINE
							GetFMDandSMD(ref OMD, ref OMD_Last, DT);

							// MACHINE MONITORING ABFRAGE FÜR DIESE MASCHINE
							GetMMD(ref OMD, ref OMD_Last, DT);

							logger.LogInfo("{0}: Machine: {1}: All Data correctly processed", getName(), Machines[i].Ma_Name);
						}
						else
						{
							logger.LogWarning("{0}: Machine: {1}: No Limit defined!", getName(), Machines[i].Ma_Name);
						}

					}
				}
			}
		}
		/// <summary>
		/// Speichert (von Subfunktionen angefertigte) DB-Zeilen in der Datenbank, je nachdem was in den Einstellungen konfiguriert ist. 
		/// </summary>
		/// <param name="OMD"></param>
		/// <param name="OMD_Last"></param>
		private void GetFMDandSMD(ref RCS.T_overviewmonitoringdata OMD, ref RCS.T_overviewmonitoringdata OMD_Last, DateTime DT)
		{
			// TODO: Abfrage ob Zeitpunkt des Statistik und StateStat Datensatzes gleich ist bei Links oder Rechts

			RCS.T_programs Pr = null;
			RCS.T_machinelimits Ml = null;
			RCS.T_feedingmonitoringprograms FMP = null;
			RCS.T_limits Lim = null;
			Int16[] sortprog = new Int16[1];
			sortprog[0] = 0;

			String Str = "SELECT ";
			// Abfrage für die jeweilige Seite
			Str += "(SELECT ss.ss_sorting_num_0 FROM StateStat AS ss WHERE ss.Ma_ID = " + OMD.Ma_ID + " ORDER BY ss.Ss_TimeStamp DESC LIMIT 1) AS Profil_Left;";

			Int32 rv = DBTools.select_c_row(Str, sortprog);

			// Programm laden und Load berechnen
			// Linke Seite
			if (rv > 0 && sortprog[0] >= 0)
			{
				// Program abfragen
				Pr = (RCS.T_programs)DBTools.select_row(RCS.E_Tables.E_T_programs, "Pr_Number = " + sortprog[0] + " AND Ma_ID = " + OMD.Ma_ID + " AND Si_ID = " + OMD.Si_ID.ToString() + " AND Pr_Status <> " + (short)RCS.Status.DELETED);

				if (Pr == null)
				{
					// Nicht alle Programme von Maschine in DB (Programm Update machen) z.b. bei Spur 2 aktivierung!!!
					for (Int32 m = 0; m < Machines.Length; m++)
					{
						if (Machines[m].Ma_ID == OMD.Ma_ID)
						{
							logger.LogError("{0}: There are not all needed Programs and Classes in the Database!! Update SortingProgram {1} of the Machine {2} on SlideSide {3} in the Configuration!!", getName(), sortprog[0], Machines[m].Ma_Name, OMD.Si_ID.ToString());
							break;
						}
					}
					return;
				}
				// Limit der ausgelesenen Maschine holen
				Ml = (RCS.T_machinelimits)DBTools.select_row(RCS.E_Tables.E_T_machinelimits, "Pr_ID = " + Pr.Pr_ID + " AND Si_ID = " + Pr.Si_ID + " AND Ml_Status <> " + (short)RCS.Status.DELETED);
				FMP = (RCS.T_feedingmonitoringprograms)DBTools.select_row(RCS.E_Tables.E_T_feedingmonitoringprograms, "Pr_ID = " + Pr.Pr_ID + " AND Fp_Status <> " + (short)RCS.Status.DELETED);

				// Kein Limit für dieses Program
				if (Ml != null && FMP != null)
				{
					if (FMP.Fp_Check == 1)
					{
						Lim = (RCS.T_limits)DBTools.select_row(RCS.E_Tables.E_T_limits, "Li_ID = " + Ml.Li_ID + " AND Li_Status <> " + (short)RCS.Status.DELETED);

						// Berechnet den Unterschied zum Limit (FeedingMonitoring Berechnung nur wenn in FeedingMonitoring das aktivierte Programm überwacht wird)
						RCS.T_feedingmonitoringdata[] FMD_Arr = null;
						FMD_Arr = FillFMD_Arr(ref OMD, ref OMD_Last, ref FMP, ref Lim, DT);
						DBTools.insert_rows(RCS.E_Tables.E_T_feedingmonitoringdata, FMD_Arr);

						// Berechnen von Screenmats und in die DB schieben
						RCS.T_screenmatsmonitoringdata SMD = null;
						SMD = FillSMD(ref OMD, ref OMD_Last, ref FMP, ref Lim, DT);
						if (SMD != null)
							DBTools.insert_row(RCS.E_Tables.E_T_screenmatsmonitoringdata, SMD);
					}
				}
			}
		}

		/// <summary>
		/// Anhand der in den Einstellungen angehakten zu prüfenden Felder stellt diese Funktion eine fertige DB-Zeile mit allen bewerteten Daten bereit
		/// </summary>
		/// <param name="OMD"></param>
		/// <param name="OMD_Last"></param>
		/// <param name="FMP"></param>
		/// <param name="Lim"></param>
		/// <returns></returns>
		private RCS.T_screenmatsmonitoringdata FillSMD(
			ref RCS.T_overviewmonitoringdata OMD,
			ref RCS.T_overviewmonitoringdata OMD_Last,
			ref RCS.T_feedingmonitoringprograms FMP,
			ref RCS.T_limits Lim,
			DateTime DT)
		{
			// Befüllen von ScreenMatsMonitoringData
			RCS.T_screenmatsmonitoringdata SMD = new RCS.T_screenmatsmonitoringdata();
			DateTime[] Timestamp = new DateTime[1];
			RCS.T_screenmatsmonitoringdata SMD_Last = null;
			Boolean Write = false;

			RCS.T_statistic ST = (RCS.T_statistic)DBTools.select_row(RCS.E_Tables.E_T_statistic, " Ma_ID = " + OMD.Ma_ID + " AND Si_ID = " + OMD.Si_ID + " ORDER BY St_TimeStamp DESC LIMIT 1");
			RCS.T_feedingmonitoring FM = (RCS.T_feedingmonitoring)DBTools.select_row(RCS.E_Tables.E_T_feedingmonitoring, "Fm_ID = " + FMP.Fm_ID + " AND Fm_Status <> " + (short)RCS.Status.DELETED);

			if (OMD_Last != null)
				SMD_Last = (RCS.T_screenmatsmonitoringdata)DBTools.select_row(RCS.E_Tables.E_T_screenmatsmonitoringdata, " Od_ID = " + OMD_Last.Od_ID);


			if (FMP.Fp_Cornsize25Check == 1)
			{
				if (ST.St_Cornsize_25 > Lim.Li_Cornsize25Max)
				{
					if (SMD.Sd_Cornstate == 1 || SMD.Sd_Cornstate == 3)
						SMD.Sd_Cornstate = 3;
					else
						SMD.Sd_Cornstate = 2;
				}
				if (ST.St_Cornsize_25 < Lim.Li_Cornsize25Min && ST.St_Cornsize_25 > 0)
				{
					if (SMD.Sd_Cornstate == 2 || SMD.Sd_Cornstate == 3)
						SMD.Sd_Cornstate = 3;
					else
						SMD.Sd_Cornstate = 1;
				}
				Write = true;
			}
			if (FMP.Fp_CornsizeMedianCheck == 1)
			{
				if (ST.St_Cornsize_Median > Lim.Li_CornsizeMedianMax)
				{
					if (SMD.Sd_Cornstate == 1 || SMD.Sd_Cornstate == 3)
						SMD.Sd_Cornstate = 3;
					else
						SMD.Sd_Cornstate = 2;
				}
				if (ST.St_Cornsize_Median < Lim.Li_CornsizeMedianMin && ST.St_Cornsize_Median > 0)
				{
					if (SMD.Sd_Cornstate == 2 || SMD.Sd_Cornstate == 3)
						SMD.Sd_Cornstate = 3;
					else
						SMD.Sd_Cornstate = 1;
				}
				Write = true;
			}
			if (FMP.Fp_Cornsize75Check == 1)
			{
				if (ST.St_Cornsize_75 > Lim.Li_Cornsize75Max)
				{
					if (SMD.Sd_Cornstate == 1 || SMD.Sd_Cornstate == 3)
						SMD.Sd_Cornstate = 3;
					else
						SMD.Sd_Cornstate = 2;
				}
				if (ST.St_Cornsize_75 < Lim.Li_Cornsize75Min && ST.St_Cornsize_75 > 0)
				{
					if (SMD.Sd_Cornstate == 2 || SMD.Sd_Cornstate == 3)
						SMD.Sd_Cornstate = 3;
					else
						SMD.Sd_Cornstate = 1;
				}
				Write = true;
			}

			if (Write == true)
			{
				SMD.Od_ID = OMD.Od_ID;
				SMD.Sd_TimeStamp = DT;
				SMD.Sd_Cornsize_25_Min = Lim.Li_Cornsize25Min;
				SMD.Sd_Cornsize_25 = ST.St_Cornsize_25;
				SMD.Sd_Cornsize_25_Max = Lim.Li_Cornsize25Max;
				SMD.Sd_Cornsize_Median_Min = Lim.Li_CornsizeMedianMin;
				SMD.Sd_Cornsize_Median = ST.St_Cornsize_Median;
				SMD.Sd_Cornsize_Median_Max = Lim.Li_CornsizeMedianMax;
				SMD.Sd_Cornsize_75_Min = Lim.Li_Cornsize75Min;
				SMD.Sd_Cornsize_75 = ST.St_Cornsize_75;
				SMD.Sd_Cornsize_75_Max = Lim.Li_Cornsize75Max;

				RateSMD(ref SMD, ref SMD_Last, ref FM);

				return SMD;
			}

			return null;
		}

		/// <summary>
		/// Bewertet die Screenmats Daten und gibt sie zurück
		/// </summary>
		/// <param name="SMD">Fertige Zeile</param>
		/// <param name="SMD_Last"></param>
		/// <param name="FM"></param>
		/// <returns></returns>
		private Int32 RateSMD(
					ref RCS.T_screenmatsmonitoringdata SMD,
					ref RCS.T_screenmatsmonitoringdata SMD_Last,
					ref RCS.T_feedingmonitoring FM)
		{

			if (SMD_Last != null)
			{
				SMD.Sd_State = SMD_Last.Sd_State;
				SMD.Sd_Reported = SMD_Last.Sd_Reported;
				SMD.Sd_Marked = SMD_Last.Sd_Marked;

				// Ist Wert über oder/und unter Grenze
				if (SMD.Sd_Cornstate == 1 || SMD.Sd_Cornstate == 2 || SMD.Sd_Cornstate == 3)
				{
					// Setzt wenn erste mal über/unter Grenzen
					// Marked erhöhen solange Wert über/unter Grenze
					if (SMD_Last.Sd_State == 0 || SMD_Last.Sd_State == 1 || SMD_Last.Sd_State == -1 || SMD_Last.Sd_State == 4)
					{
						SMD.Sd_Marked = Convert.ToInt16(SMD_Last.Sd_Marked + 1);
						SMD.Sd_Reported = 0;
						if (SMD.Sd_Cornstate == 1)
							SMD.Sd_State = -1;
						else if (SMD.Sd_Cornstate == 2)
							SMD.Sd_State = 1;
						else if (SMD.Sd_Cornstate == 3)
							SMD.Sd_State = 4;

						// Setze Reported wenn wert ActivationDelay über/unter Grenze (Meldung wird ausgegeben)
						if (SMD.Sd_Marked >= (FM.Fm_ActivationDelay_SM + 1))
						{
							SMD.Sd_Marked = 0;
							SMD.Sd_Reported = 1;
							if (SMD.Sd_Cornstate == 1)
								SMD.Sd_State = -2;
							else if (SMD.Sd_Cornstate == 2)
								SMD.Sd_State = 2;
							else if (SMD.Sd_Cornstate == 3)
								SMD.Sd_State = 5;
						}
					}
					// Rücksetzen wenn nicht mehr über/unter Grenze
					else if (SMD_Last.Sd_State == 2 || SMD_Last.Sd_State == -2 || SMD_Last.Sd_State == 5)
					{
						SMD.Sd_Marked = Convert.ToInt16(SMD_Last.Sd_Marked + 1);
						SMD.Sd_Reported = SMD_Last.Sd_Reported;
						SMD.Sd_State = SMD_Last.Sd_State;
					}
					else if (SMD_Last.Sd_State == 3 || SMD_Last.Sd_State == -3 || SMD_Last.Sd_State == 6)
					{
						SMD.Sd_Marked = 0;
						SMD.Sd_Reported = SMD_Last.Sd_Reported;
						if (SMD.Sd_Cornstate == 1)
							SMD.Sd_State = -2;
						else if (SMD.Sd_Cornstate == 2)
							SMD.Sd_State = 2;
						else if (SMD.Sd_Cornstate == 3)
							SMD.Sd_State = 5;
					}
				}
				// Wenn Reported == 1
				else if (SMD_Last.Sd_State == 2)
				{
					SMD.Sd_Marked = 0;
					SMD.Sd_Reported = 1;
					SMD.Sd_State = 3;
				}
				// Wenn Reported == 1
				else if (SMD_Last.Sd_State == -2)
				{
					SMD.Sd_Marked = 0;
					SMD.Sd_Reported = 1;
					SMD.Sd_State = -3;
				}
				// Wenn Reported == 1
				else if (SMD_Last.Sd_State == 5)
				{
					SMD.Sd_Marked = 0;
					SMD.Sd_Reported = 1;
					SMD.Sd_State = 6;
				}
				// Zähler, muss extra in dieser If-Kette stehen damit er nicht nach Marker 0-stellung nochmal zum LAST 1 addiert.
				else if (SMD.Sd_State == 3 || SMD.Sd_State == -3 || SMD.Sd_State == 6)
				{
					SMD.Sd_Marked = Convert.ToInt16(SMD_Last.Sd_Marked + 1);
					SMD.Sd_Reported = SMD_Last.Sd_Reported;
					SMD.Sd_State = SMD_Last.Sd_State;
				}
				else
				{
					SMD.Sd_Marked = 0;
					SMD.Sd_Reported = 0;
					SMD.Sd_State = 0;
				}

				if (SMD.Sd_State == 3 || SMD.Sd_State == -3 || SMD.Sd_State == 6)
				{
					// Wenn Wert wieder normal, dann nach ResetDelay wieder auf normal
					if (SMD.Sd_Marked >= (FM.Fm_ResetDelay_SM + 1))
					{
						SMD.Sd_Marked = 0;
						SMD.Sd_Reported = 0;
						SMD.Sd_State = 0;
					}
				}
			}
			else
			{
				SMD.Sd_Marked = 0;
				SMD.Sd_Reported = 0;
				SMD.Sd_State = 0;
			}

			return 0;
		}

		/// <summary>
		///  MACHINEMONITORING
		/// </summary>
		/// <param name="OMD"></param>
		/// <param name="OMD_Last"></param>
		private void GetMMD(ref RCS.T_overviewmonitoringdata OMD,
			ref RCS.T_overviewmonitoringdata OMD_Last,
			DateTime DT)
		{
			RCS.T_machinemonitoring[] MM = null;
			RCS.T_classes[] CL = null;
			RCS.T_machinemonitoringdata[] MMD = null;
			RCS.T_machinemonitoringdata[] MMD_Last = null;
			RCS.T_machinemonitoringprograms MMP = null;
			RCS.T_machinemonitoringclasses[] MMC = null;
			RCS.T_statistic ST_W = null;
			RCS.T_statistic ST_T = null;
			MachineRecord[] MR = null;
			MachineCalculate MachCalc = null;
			RCS.T_machines MA = null;
			Int32 c = 0;
			Int32 Shoult_be = 0;

			// MachineMonitoringData mit gesammelten Daten befüllen
			MM = (RCS.T_machinemonitoring[])DBTools.select_rows(RCS.E_Tables.E_T_machinemonitoring, "Ma_ID_Watching = " + OMD.Ma_ID + " AND Si_ID_Watching = " + OMD.Si_ID + " AND Mm_Status <> " + (short)RCS.Status.DELETED, 0);

			if (MM != null)
			{
				for (Int32 k = 0; k < MM.Length; k++)
				{
					MMP = null;
					MMP = (RCS.T_machinemonitoringprograms)DBTools.select_row(RCS.E_Tables.E_T_machinemonitoringprograms, "Pr_ID = (SELECT Pr_ID FROM programs WHERE Pr_Number = " + OMD.Od_SortProg + " AND Ma_ID = " + MM[k].Ma_ID_ToWatch + " AND Si_ID = " + MM[k].Si_ID_ToWatch + " AND Pr_Status <> " + (short)RCS.Status.DELETED + ")" +
						" AND Mm_ID = " + MM[k].Mm_ID +
						" AND Mp_Status <> " + (short)RCS.Status.DELETED);

					if (MMP == null || MMP.Mp_Check != 1)
						continue;

					CL = null;
					CL = (RCS.T_classes[])DBTools.select_rows(RCS.E_Tables.E_T_classes, "Pr_ID = (SELECT Pr_ID FROM programs WHERE Pr_Number = " + OMD.Od_SortProg + " AND Ma_ID = " + MM[k].Ma_ID_ToWatch + " AND Si_ID = " + MM[k].Si_ID_ToWatch + " AND Pr_Status <> " + (short)RCS.Status.DELETED + ")" +
						" AND Cl_Status <> " + (short)RCS.Status.DELETED, 0);

					MR = null;
					MR = new MachineRecord[1];
					MachCalc = null;
					MachCalc = new MachineCalculate();

					ST_W = null;
					ST_T = null;
					ST_W = (RCS.T_statistic)DBTools.select_row(RCS.E_Tables.E_T_statistic, "Ma_ID = " + MM[k].Ma_ID_Watching + " AND Si_ID = " + MM[k].Si_ID_Watching + " ORDER BY St_Timestamp DESC LIMIT 1");
					ST_T = (RCS.T_statistic)DBTools.select_row(RCS.E_Tables.E_T_statistic, "Ma_ID = " + MM[k].Ma_ID_ToWatch + " AND Si_ID = " + MM[k].Si_ID_ToWatch + " ORDER BY St_Timestamp DESC LIMIT 1");

					if (CL != null && ST_W != null && ST_T != null)
					{
						for (Int32 i = 0; i < CL.Length; i++)
						{
							// Durchlauf
							if (CL[i] == null)
								continue;

							if (MR.Length < (i + 1))
								Array.Resize<MachineRecord>(ref MR, MR.Length + 1);
							if (MR[i] == null)
								MR[i] = new MachineRecord();

							MR[i] = new MachineRecord();
							MR[i].Cl_ID = CL[i].Cl_ID;
							MR[i].ClassLabel = CL[i].Cl_ClassLabel;
							MR[i].ClassName = CL[i].Cl_Name;
							MR[i].ShotChannel = CL[i].Sh_ID;
							MR[i].Objects = MachCalc.GetStatClassValue(CL[i].Cl_ClassLabel, ST_T);
							MR[i].Efficiency = CL[i].Cl_Efficiency;
							MR[i].OverSort = CL[i].Cl_OverSort;
							MR[i].Efficiency_Var = CL[i].Cl_EfficiencyVariance;
							MR[i].OverSort_Var = CL[i].Cl_OverSortVariance;
						}

						MA = null;
						MA = (RCS.T_machines)DBTools.select_row(RCS.E_Tables.E_T_machines, "Ma_ID = " + MM[k].Ma_ID_ToWatch + " AND Ma_Status <> " + (short)RCS.Status.DELETED);
						if (MA == null)
							continue;
						// BERECHNUNGSFUNKTION
						MR = MachCalc.Calculate(MR, Convert.ToInt32(MA.Rj_ID));

						MMD = new RCS.T_machinemonitoringdata[1];
						Shoult_be = 0;
						c = 0;

						MMC = (RCS.T_machinemonitoringclasses[])DBTools.select_rows(RCS.E_Tables.E_T_machinemonitoringclasses, "Mm_ID = " + MM[k].Mm_ID + " AND Mc_Status <> " + (short)RCS.Status.DELETED, 0);
						if (MMC == null)
							continue;

						for (Int32 j = 0; j < MR.Length; j++)
						{
							for (Int32 l = 0; l < MMC.Length; l++)
							{
								if (MR[j].Cl_ID == MMC[l].Cl_ID)
								{
									if (MMC[l].Mc_Check == 1)
									{
										if (MMD.Length < (c + 1))
											Array.Resize<RCS.T_machinemonitoringdata>(ref MMD, MMD.Length + 1);
										if (MMD[c] == null)
											MMD[c] = new RCS.T_machinemonitoringdata();

										Shoult_be = 0;
										if (MR[j].ShotChannel == 1)
											Shoult_be = MR[j].Pass;
										else if (MR[j].ShotChannel == 2)
											Shoult_be = MR[j].Reject1;
										else if (MR[j].ShotChannel == 3)
											Shoult_be = MR[j].Reject2;

										// Auswertung
										Int32 Variance_Max = Shoult_be + (Shoult_be * Convert.ToInt32(MR[j].Efficiency_Var / 100.0f / 100.0f));
										Int32 Variance_Min = Shoult_be - (Shoult_be * Convert.ToInt32(MR[j].Efficiency_Var / 100.0f / 100.0f));
										Int32 Is = MachCalc.GetStatClassValue(MR[j].ClassLabel, ST_W);

										if (OMD_Last != null)
											MMD_Last = (RCS.T_machinemonitoringdata[])DBTools.select_rows(RCS.E_Tables.E_T_machinemonitoringdata, "Od_ID = " + OMD_Last.Od_ID + " AND Ma_ID_ToWatch = " + MM[k].Ma_ID_ToWatch + " AND Si_ID_ToWatch = " + MM[k].Si_ID_ToWatch, 0);

										if (MMD_Last != null)
										{
											for (Int32 m = 0; m < MMD_Last.Length; m++)
											{
												if (MMD_Last[m].Md_ClassName == MR[j].ClassName)
												{
													MMD[c] = CreateMMDRow(Is, Shoult_be, MR[j].Efficiency_Var, ref MMD_Last[m], ref MM[k]);
													break;
												}
											}
										}
										MMD[c].Od_ID = OMD.Od_ID;
										MMD[c].Ma_ID_ToWatch = MM[k].Ma_ID_ToWatch;
										MMD[c].Si_ID_ToWatch = MM[k].Si_ID_ToWatch;
										MMD[c].Sh_ID_ToWatch = MM[k].Sh_ID_ToWatch;
										MMD[c].Md_Shoult_be = Shoult_be;
										MMD[c].Md_Is = Is;
										MMD[c].Md_ClassLabel = MR[j].ClassLabel;
										MMD[c].Md_ClassName = MR[j].ClassName;
										Int32 Variance = 0;
										if (Is != 0 && Shoult_be != 0)
											Variance = Convert.ToInt32((100 * Is / Shoult_be) - 100);
										MMD[c].Md_Variance = Variance;
										MMD[c].Md_Variance_Max = MR[j].Efficiency_Var;
										MMD[c].Md_TimeStamp = DT;
										c++;
									}
								}
							}
						}
						DBTools.insert_rows(RCS.E_Tables.E_T_machinemonitoringdata, (Object)MMD);
					}
				}
			}
		}

		/// <summary>
		/// Bewertet MachineMonitoring Daten, jeweils eine Klasse
		/// Wird von "GetMMD" aufgerufen
		/// </summary>
		/// <param name="Is_in"></param>
		/// <param name="Shoult_be_in"></param>
		/// <param name="Variance_in"></param>
		/// <param name="MMD_Last"></param>
		/// <param name="MM"></param>
		/// <returns></returns>
		private RCS.T_machinemonitoringdata CreateMMDRow(
					Int32 Is_in,
					Int32 Shoult_be_in,
					Int32 Variance_in,
					ref RCS.T_machinemonitoringdata MMD_Last,
					ref RCS.T_machinemonitoring MM)
		{
			RCS.T_machinemonitoringdata MMD = new RCS.T_machinemonitoringdata();
			Single Is = Convert.ToSingle(Is_in);
			Int32 Shoult_be = Shoult_be_in;
			Int32 Variance = Variance_in;

			Int32 Objects_max = Shoult_be + Convert.ToInt32(Shoult_be * (Variance / 100.0f));
			Int32 Objects_min = Shoult_be - Convert.ToInt32(Shoult_be * (Variance / 100.0f));

			if (MMD_Last != null && Shoult_be != 0)
			{
				MMD.Md_State = MMD_Last.Md_State;
				MMD.Md_Reported = MMD_Last.Md_Reported;

				if (MMD_Last.Md_Reported == 0)
				{
					// Setzt Marked wenn Value über Limit
					if (Is > Objects_max)
					{
						MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked + 1);
						MMD.Md_State = 1;
					}
					// Setzt Marked wenn Value unter Limit
					else if (Is < Objects_min)
					{
						MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked - 1);
						MMD.Md_State = -1;
					}
					// Wenn einmal wieder normal, dann auf 0
					else
					{
						MMD.Md_Marked = 0;
						MMD.Md_State = 0;
					}

					// Wenn Verzögerung erreicht, dann Reported setzen
					if (MMD.Md_State == 1 || MMD.Md_State == -1)
					{
						if (MMD.Md_Marked >= (MM.Mm_ActivationDelay + 1))
						{
							MMD.Md_Marked = 0;
							MMD.Md_Reported = 1;
							MMD.Md_State = 2;
						}
						if (MMD.Md_Marked <= ((MM.Mm_ActivationDelay + 1) * (-1)))
						{
							MMD.Md_Marked = 0;
							MMD.Md_Reported = -1;
							MMD.Md_State = -2;
						}
					}
				}
				if (MMD_Last.Md_Reported > 0)
				{
					// Wenn Reported gesetzt und Wert wieder normal, dann Marked so lange minus zählen, bis Reset-Verzögerung erreicht.
					if (Is < Objects_max)
					{
						if (MMD_Last.Md_Marked >= 0)
							MMD.Md_Marked = -1;
						else
							MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked - 1);
						MMD.Md_State = 3;
					}
					else
					{
						// Zählt, wie lang schon über Limit
						if (MMD_Last.Md_Marked >= 0)
							MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked + 1);
						// Wenn einmal wieder über Limit, dann auf 0 zurück
						else
							MMD.Md_Marked = 0;
						MMD.Md_State = 2;
					}

					// Wenn Marked über Reset-Wert, dann Reported wieder auf 0
					if (MMD.Md_State == 3)
					{
						MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked);

						if (MMD.Md_Marked <= ((MM.Mm_ResetDelay + 1) * (-1)))
						{
							MMD.Md_Marked = 0;
							MMD.Md_Reported = 0;
							MMD.Md_State = 0;
						}
						else
						{
							if (MMD_Last.Md_State == 2)
								MMD.Md_Marked = -1;
							else
								MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked - 1);
						}
					}
				}
				if (MMD_Last.Md_Reported < 0)
				{
					if (Is > Objects_min)
					{
						if (MMD_Last.Md_Marked <= 0)
							MMD.Md_Marked = 1;
						else
							MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked + 1);
						MMD.Md_State = -3;
					}
					else
					{
						// Zählt, wie lang schon unter Limit
						if (MMD_Last.Md_Marked <= 0)
							MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked - 1);
						// Wenn einmal wieder unter Limit, dann auf 0 zurück
						else
							MMD.Md_Marked = 0;
						MMD.Md_State = -2;
					}

					// Wenn Marked über Reset-Wert, dann Reported wieder auf 0
					if (MMD.Md_State == -3)
					{
						if (MMD.Md_Marked >= (MM.Mm_ResetDelay + 1))
						{
							MMD.Md_Marked = 0;
							MMD.Md_Reported = 0;
							MMD.Md_State = 0;
						}
						else
						{
							if (MMD_Last.Md_State == -2)
								MMD.Md_Marked = 1;
							else
								MMD.Md_Marked = Convert.ToInt16(MMD_Last.Md_Marked + 1);
						}
					}
				}
			}
			else
			{
				MMD.Md_Marked = 0;
				MMD.Md_Reported = 0;
				MMD.Md_State = 0;
			}
			return MMD;
		}

		/// <summary>
		/// Erstellt die FeedingMonitoring Zeile aus den mitgegebenen Daten.
		/// Wird von "FillFMD_Arr" aufgerufen
		/// </summary>
		/// <param name="Value_in"></param>
		/// <param name="Objects_min"></param>
		/// <param name="Objects_max"></param>
		/// <param name="CurveType_Idx"></param>
		/// <param name="Od_ID"></param>
		/// <param name="FMD_Last">Letzter Generierter Datensatz der jeweiligen Maschine und SlideSide</param>
		/// <param name="FM">Einstellungen</param>
		/// <returns></returns>
		private T_feedingmonitoringdata CreateFMDRow(
					Int32 Value_in,
					Int32 Objects_min,
					Int32 Objects_max,
					Int32 CurveType_Idx,
					Int32 Od_ID,
					ref T_feedingmonitoringdata FMD_Last,
					ref T_feedingmonitoring FM,
					DateTime DT)
		{
			T_feedingmonitoringdata FMD = new T_feedingmonitoringdata();

			Int32 Value = Value_in;

			if (FMD_Last != null)
			{
				FMD.Fd_Marked = FMD_Last.Fd_Marked;
				FMD.Fd_State = FMD_Last.Fd_State;
				FMD.Fd_Reported = FMD_Last.Fd_Reported;

				if (FMD_Last.Fd_Reported == 0)
				{
					// Setzt Marked wenn Value über Limit
					if (Value > Objects_max)
					{
						FMD.Fd_Marked = Convert.ToInt16(FMD_Last.Fd_Marked + 1);
						FMD.Fd_State = 1;
					}
					// Setzt Marked wenn Value unter Limit
					else if (Value < Objects_min)
					{
						FMD.Fd_Marked = Convert.ToInt16(FMD_Last.Fd_Marked - 1);
						FMD.Fd_State = -1;
					}
					// Wenn einmal wieder normal, dann auf 0
					else
					{
						FMD.Fd_Marked = 0;
						FMD.Fd_State = 0;
					}
					// Wenn Verzögerung erreicht, dann Reported setzen
					if (FMD.Fd_State == 1 || FMD.Fd_State == -1)
					{
						if (FMD.Fd_Marked >= (FM.Fm_ActivationDelay_FM + 1))
						{
							FMD.Fd_Marked = 0;
							FMD.Fd_Reported = 1;
							FMD.Fd_State = 2;
						}
						if (FMD.Fd_Marked <= ((FM.Fm_ActivationDelay_FM + 1) * (-1)))
						{
							FMD.Fd_Marked = 0;
							FMD.Fd_Reported = -1;
							FMD.Fd_State = -2;
						}
					}
				}
				if (FMD_Last.Fd_Reported > 0)
				{
					// Wenn Reported gesetzt und Wert wieder normal, dann Marked so lange minus zählen, bis Reset-Verzögerung erreicht.
					if (Value < Objects_max)
					{
						if (FMD_Last.Fd_Marked >= 0)
							FMD.Fd_Marked = -1;
						else
							FMD.Fd_Marked = Convert.ToInt16(FMD_Last.Fd_Marked - 1);
						FMD.Fd_State = 3;
					}
					else
					{
						// Zählt, wie lang schon über Limit
						if (FMD_Last.Fd_Marked >= 0)
							FMD.Fd_Marked = Convert.ToInt16(FMD_Last.Fd_Marked + 1);
						// Wenn einmal wieder über Limit, dann auf 0 zurück
						else
							FMD.Fd_Marked = 0;
						FMD.Fd_State = 2;
					}
					// Wenn Marked über Reset-Wert, dann Reported wieder auf 0
					if (FMD.Fd_State == 3)
					{
						if (FMD.Fd_Marked <= ((FM.Fm_ResetDelay_FM + 1) * (-1)))
						{
							FMD.Fd_Marked = 0;
							FMD.Fd_Reported = 0;
							FMD.Fd_State = 0;
						}
					}
				}
				if (FMD_Last.Fd_Reported < 0)
				{
					if (Value > Objects_min)
					{
						if (FMD_Last.Fd_Marked <= 0)
							FMD.Fd_Marked = 1;
						else
							FMD.Fd_Marked = Convert.ToInt16(FMD_Last.Fd_Marked + 1);
						FMD.Fd_State = -3;
					}
					else
					{
						// Zählt, wie lang schon unter Limit
						if (FMD_Last.Fd_Marked <= 0)
							FMD.Fd_Marked = Convert.ToInt16(FMD_Last.Fd_Marked - 1);
						// Wenn einmal wieder unter Limit, dann auf 0 zurück
						else
							FMD.Fd_Marked = 0;
						FMD.Fd_State = -2;
					}
					// Wenn Marked über Reset-Wert, dann Reported wieder auf 0
					if (FMD.Fd_State == -3)
					{
						if (FMD.Fd_Marked >= (FM.Fm_ResetDelay_FM + 1))
						{
							FMD.Fd_Marked = 0;
							FMD.Fd_Reported = 0;
							FMD.Fd_State = 0;
						}
					}
				}
			}
			else
			{
				FMD.Fd_Marked = 0;
				FMD.Fd_Reported = 0;
				FMD.Fd_State = 0;
			}

			FMD.Od_ID = Od_ID;
			FMD.Ct_ID = (CommonTools.getCurveType_ByMonitorType(CT, Convert.ToInt32(CurveType_Idx))).Ct_ID;
			FMD.Fd_Value = Value_in;
			FMD.Fd_Feeding_Group = FM.Fm_FeedingGroup;
			FMD.Fd_Limit_Min = Objects_min;
			FMD.Fd_Limit_Max = Objects_max;
			FMD.Fd_TimeStamp = DT;

			return FMD;
		}

		/// <summary>
		/// Stellt ein Array mit Zeile her, das bereit zum Speichern in die DB ist.
		/// Ruft "CreateFMDRow" auf
		/// Wird von "GetFMDandSMD" aufgerufen
		/// </summary>
		/// <param name="OMD"></param>
		/// <param name="OMD_Last"></param>
		/// <param name="FMP"></param>
		/// <param name="Lim"></param>
		/// <returns></returns>
		private T_feedingmonitoringdata[] FillFMD_Arr(
			ref T_overviewmonitoringdata OMD,
			ref T_overviewmonitoringdata OMD_Last,
			ref T_feedingmonitoringprograms FMP,
			ref T_limits Lim,
			DateTime DT)
		{
			// Befüllen von FeedingMonitoringData
			T_feedingmonitoringdata FMD_rv = new T_feedingmonitoringdata();
			T_feedingmonitoringdata[] FMD_Arr = new T_feedingmonitoringdata[1];
			DateTime[] Timestamp = new DateTime[1];
			T_feedingmonitoringdata[] FMD_Last_Arr = null;
			T_feedingmonitoringdata FMD_Last = null;

			T_feedingmonitoring FM = (T_feedingmonitoring)DBTools.select_row(E_Tables.E_T_feedingmonitoring, "Fm_ID = " + FMP.Fm_ID + " AND Fm_Status <> " + (short)Status.DELETED);

			if (OMD_Last != null)
				FMD_Last_Arr = (T_feedingmonitoringdata[])DBTools.select_rows(E_Tables.E_T_feedingmonitoringdata, " Od_ID = " + OMD_Last.Od_ID, 0);

			if (FM != null)
			{
				if ((OMD.Od_Objects + OMD.Od_Objects_Rej1 + OMD.Od_Objects_Rej2) > FM.Fm_MinObjects/* && FMD_Last != null*/)
				{
					if (FMP.Fp_NrOfObjCheck == 1)
					{
						FMD_Last = null;
						if (FMD_Last_Arr != null)
						{
							for (Int32 i = 0; i < FMD_Last_Arr.Length; i++)
							{
								if (FMD_Last_Arr[i].Ct_ID == (CommonTools.getCurveType_ByMonitorType(CT, 1)).Ct_ID)
								{
									FMD_Last = FMD_Last_Arr[i];
									break;
								}
								else
									FMD_Last = null;
							}
						}
						FMD_rv = CreateFMDRow(OMD.Od_Objects, Lim.Li_NrOfObjMin, Lim.Li_NrOfObjMax, 1, OMD.Od_ID, ref FMD_Last, ref FM, DT);
						if (FMD_rv != null)
						{
							if (FMD_Arr[FMD_Arr.Length - 1] != null)
								Array.Resize<T_feedingmonitoringdata>(ref FMD_Arr, FMD_Arr.Length + 1);
							FMD_Arr[FMD_Arr.Length - 1] = FMD_rv;
						}
					}
					if (FMP.Fp_NrOfObRej_B1Check == 1)
					{
						FMD_Last = null;
						if (FMD_Last_Arr != null)
						{
							for (Int32 i = 0; i < FMD_Last_Arr.Length; i++)
							{
								if (FMD_Last_Arr[i].Ct_ID == (CommonTools.getCurveType_ByMonitorType(CT, 2)).Ct_ID)
								{
									FMD_Last = FMD_Last_Arr[i];
									break;
								}
								else
									FMD_Last = null;
							}
						}
						FMD_rv = CreateFMDRow(OMD.Od_Objects_Rej1, Lim.Li_NrOfObjRejMin_B1, Lim.Li_NrOfObjRejMax_B1, 2, OMD.Od_ID, ref FMD_Last, ref FM, DT);
						if (FMD_rv != null)
						{
							if (FMD_Arr[FMD_Arr.Length - 1] != null)
								Array.Resize<T_feedingmonitoringdata>(ref FMD_Arr, FMD_Arr.Length + 1);
							FMD_Arr[FMD_Arr.Length - 1] = FMD_rv;
						}
					}
					if (FMP.Fp_NrOfObRej_B2Check == 1)
					{
						FMD_Last = null;
						if (FMD_Last_Arr != null)
						{
							for (Int32 i = 0; i < FMD_Last_Arr.Length; i++)
							{
								if (FMD_Last_Arr[i].Ct_ID == (CommonTools.getCurveType_ByMonitorType(CT, 3)).Ct_ID)
								{
									FMD_Last = FMD_Last_Arr[i];
									break;
								}
								else
									FMD_Last = null;
							}
						}
						FMD_rv = CreateFMDRow(OMD.Od_Objects_Rej2, Lim.Li_NrOfObjRejMin_B2, Lim.Li_NrOfObjRejMax_B2, 3, OMD.Od_ID, ref FMD_Last, ref FM, DT);
						if (FMD_rv != null)
						{
							if (FMD_Arr[FMD_Arr.Length - 1] != null)
								Array.Resize<T_feedingmonitoringdata>(ref FMD_Arr, FMD_Arr.Length + 1);
							FMD_Arr[FMD_Arr.Length - 1] = FMD_rv;
						}
					}
					if (FMP.Fp_WeightCheck == 1)
					{
						FMD_Last = null;
						if (FMD_Last_Arr != null)
						{
							for (Int32 i = 0; i < FMD_Last_Arr.Length; i++)
							{
								if (FMD_Last_Arr[i].Ct_ID == (CommonTools.getCurveType_ByMonitorType(CT, 4)).Ct_ID)
								{
									FMD_Last = FMD_Last_Arr[i];
									break;
								}
								else
									FMD_Last = null;
							}
						}
						FMD_rv = CreateFMDRow(OMD.Od_Weight, Lim.Li_WeightMin, Lim.Li_WeightMax, 4, OMD.Od_ID, ref FMD_Last, ref FM, DT);
						if (FMD_rv != null)
						{
							if (FMD_Arr[FMD_Arr.Length - 1] != null)
								Array.Resize<T_feedingmonitoringdata>(ref FMD_Arr, FMD_Arr.Length + 1);
							FMD_Arr[FMD_Arr.Length - 1] = FMD_rv;
						}
					}
					if (FMP.Fp_WeightRej_B1Check == 1)
					{
						FMD_Last = null;
						if (FMD_Last_Arr != null)
						{
							for (Int32 i = 0; i < FMD_Last_Arr.Length; i++)
							{
								if (FMD_Last_Arr[i].Ct_ID == (CommonTools.getCurveType_ByMonitorType(CT, 5)).Ct_ID)
								{
									FMD_Last = FMD_Last_Arr[i];
									break;
								}
								else
									FMD_Last = null;
							}
						}
						FMD_rv = CreateFMDRow(OMD.Od_Weight_Rej1, Lim.Li_WeightRejMin_B1, Lim.Li_WeightRejMax_B1, 5, OMD.Od_ID, ref FMD_Last, ref FM, DT);
						if (FMD_rv != null)
						{
							if (FMD_Arr[FMD_Arr.Length - 1] != null)
								Array.Resize<T_feedingmonitoringdata>(ref FMD_Arr, FMD_Arr.Length + 1);
							FMD_Arr[FMD_Arr.Length - 1] = FMD_rv;
						}
					}
					if (FMP.Fp_WeightRej_B2Check == 1)
					{
						FMD_Last = null;
						if (FMD_Last_Arr != null)
						{
							for (Int32 i = 0; i < FMD_Last_Arr.Length; i++)
							{
								if (FMD_Last_Arr[i].Ct_ID == (CommonTools.getCurveType_ByMonitorType(CT, 6)).Ct_ID)
								{
									FMD_Last = FMD_Last_Arr[i];
									break;
								}
								else
									FMD_Last = null;
							}
						}
						FMD_rv = CreateFMDRow(OMD.Od_Weight_Rej2, Lim.Li_WeightRejMin_B2, Lim.Li_WeightRejMax_B2, 6, OMD.Od_ID, ref FMD_Last, ref FM, DT);
						if (FMD_rv != null)
						{
							if (FMD_Arr[FMD_Arr.Length - 1] != null)
								Array.Resize<T_feedingmonitoringdata>(ref FMD_Arr, FMD_Arr.Length + 1);
							FMD_Arr[FMD_Arr.Length - 1] = FMD_rv;
						}
					}
				}
			}

			//if (FMD_Arr.Length == 1 && FMD_Arr[FMD_Arr.Length - 1] == null)
			//	FMD_Arr[FMD_Arr.Length - 1] = new T_feedingmonitoringdata();

			return FMD_Arr;
		}

	}
}
