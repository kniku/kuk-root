﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RCS.Common.Logger;

namespace DCS.ManagedBeans.Implementations
{
	class LoggingBean : RCS.Common.Logger.AbstractLogger, ICallingBean
	{
		IReceivingBean logListener;

		public LoggingBean(IReceivingBean iListener)
			: base("LoggingBean")
		{
			logListener = iListener;
		}

		public override void Log(RCS.Common.Logger.LogLevel iLevel, string iMsg)
		{
			logListener.handleData(this, iLevel, iMsg);
		}

		#region ICallingBean Member

		public string getName()
		{
			return "LoggingBean";
		}

		public string getDescription()
		{
			return "LoggingBean";
		}

		public BeanState getState()
		{
			return BeanState.none;
		}

		public ILogger getLogger()
		{
			return this;
		}

		#endregion
	}
}
