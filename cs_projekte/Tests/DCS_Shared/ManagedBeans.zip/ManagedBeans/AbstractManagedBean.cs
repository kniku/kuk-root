﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using RCS.Common.Logger;

namespace DCS.ManagedBeans
{
	/// <summary>
	/// Abstrakte Basisklasse für Managed Beans OHNE eigenen Thread.
	/// Diese Objekte werden vom Master Bean zyklisch aufgerufen
	/// Siehe AbstractManagedThreadedBean für freilaufende Beans...
	/// </summary>
	abstract class AbstractManagedBean : IManagedBean
	{
		BeanState mState = BeanState.none;
		protected ArrayList listReceivingBeans = new ArrayList();
		protected RCS.Common.Logger.ILogger logger;

		/// <summary>
		/// Ruft handleData aller registriereten IReceivingBeans
		/// </summary>
		/// <param name="iData">Die zu sendenden Daten</param>
		protected void doHandleData(object iData)
		{
			foreach (IReceivingBean aBean in listReceivingBeans)
			{
				aBean.handleData(this, iData);
			}
		}

		#region IManagedBean Member

		public virtual BeanState getState()
		{
			return mState;
		}

		public abstract string getName();
		public abstract string getDescription();

		public virtual void init()
		{
			logger.pushPrefix(getName()).LogDebug(": init...").popPrefix();
			mState = BeanState.initialized;
		}

		public virtual void start()
		{
			logger.pushPrefix(getName()).LogDebug(": start...").popPrefix();
			mState = BeanState.running;
		}

		public virtual void stop()
		{
			logger.pushPrefix(getName()).LogDebug(": stop...").popPrefix();
			mState = BeanState.stopped;
		}

		public virtual void done()
		{
			mState = BeanState.none;
		}

		public void addReceivingBean(IReceivingBean iBean)
		{
			listReceivingBeans.Add(iBean);
		}

		public void setLogger(RCS.Common.Logger.ILogger iLogger)
		{
			logger = iLogger;
		}

		public ILogger getLogger()
		{
			return logger;
		}

		#endregion

		public abstract void beanRun();
	}
}
